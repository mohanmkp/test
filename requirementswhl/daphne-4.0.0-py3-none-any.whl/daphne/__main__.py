from daphne.cli import CommandLineInterface

CommandLineInterface.entrypoint()
