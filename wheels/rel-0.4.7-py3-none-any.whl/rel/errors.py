class AbortBranch(Exception):
	pass